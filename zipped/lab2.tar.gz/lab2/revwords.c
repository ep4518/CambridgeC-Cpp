#include <ctype.h>
#include <string.h>
#include "revwords.h"

void reverse_substring(char str[], int start, int end) { 
  /* TODO */
}


int find_next_start(char str[], int len, int i) { 
  /* TODO */
  return 0;
}

int find_next_end(char str[], int len, int i) {
  /* TODO */
  return 0;
}

void reverse_words(char s[]) { 
  /* TODO */
}
